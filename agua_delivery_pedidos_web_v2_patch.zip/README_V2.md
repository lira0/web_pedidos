# Água Delivery — Pedidos Web V2

Atualização da página pública de pedidos.

## Novidades da V2

- O último pedido é restaurado automaticamente depois de atualizar/fechar e reabrir a página.
- Novo botão **Acompanhar pedidos** na tela inicial.
- Busca de pedidos pelo número de WhatsApp.
- O WhatsApp funciona como identificação simples do mini cadastro nesta versão.
- A busca retorna pedido, status, data, valor e itens; não retorna endereço.
- Pedidos encontrados podem ser abertos e continuam atualizando o status normalmente.
- Ao criar pedido em outro aparelho sem `client_token`, o sistema reaproveita o cliente encontrado pelo mesmo WhatsApp.

## Atualizando uma instalação V1 existente

1. Publique os arquivos novos de `docs/` no GitHub Pages.
2. **Não substitua seu `docs/config.js` já configurado.** O ZIP de patch fornecido não contém esse arquivo.
3. No Supabase, abra **SQL Editor > New query**.
4. Copie todo o conteúdo de `supabase/upgrade_v2.sql`, execute e confirme que não houve erro.
5. Aguarde o GitHub Pages publicar e teste.

## Teste recomendado

1. Faça um pedido real.
2. Na tela de acompanhamento, atualize a página: o mesmo pedido deve reaparecer.
3. Clique em **Fazer novo pedido** para voltar ao início.
4. Clique em **Acompanhar pedidos**, informe o mesmo WhatsApp e confirme que o histórico aparece.
5. Abra um dos pedidos e altere o status no Supabase para confirmar a atualização.

O SQLite principal continua separado e não é alterado por esta atualização.

-- Água Delivery - Pedidos Web V2
-- Execute uma vez no Supabase > SQL Editor para atualizar uma instalação V1 existente.
-- Adiciona: identificação pelo WhatsApp, histórico por telefone e restauração do acompanhamento.

create index if not exists idx_web_customers_whatsapp on public.web_customers(whatsapp);

-- O WhatsApp passa a ser o identificador simples do mini cadastro.
-- Se o navegador não tiver client_token, um cliente existente com o mesmo WhatsApp é reutilizado.
create or replace function public.place_web_order(
  p_client_token uuid,
  p_name text,
  p_whatsapp text,
  p_street text,
  p_number text,
  p_neighborhood text,
  p_complement text,
  p_reference text,
  p_payment_method text,
  p_change_for numeric,
  p_items jsonb
) returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_customer_id uuid;
  v_client_token uuid;
  v_address_id uuid;
  v_order_id bigint;
  v_public_token uuid;
  v_total numeric(10,2);
  v_requested integer;
  v_matched integer;
  v_phone text;
begin
  if char_length(trim(coalesce(p_name,''))) < 2 then raise exception 'Nome inválido'; end if;
  v_phone := regexp_replace(coalesce(p_whatsapp,''), '[^0-9]', '', 'g');
  if char_length(v_phone) < 10 or char_length(v_phone) > 13 then raise exception 'WhatsApp inválido'; end if;
  if trim(coalesce(p_street,'')) = '' or trim(coalesce(p_number,'')) = '' or trim(coalesce(p_neighborhood,'')) = '' then raise exception 'Endereço incompleto'; end if;
  if p_payment_method not in ('pix','dinheiro','cartao_entrega') then raise exception 'Forma de pagamento inválida'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 or jsonb_array_length(p_items) > 50 then raise exception 'Itens inválidos'; end if;

  if p_client_token is not null then
    select c.id, c.client_token into v_customer_id, v_client_token
      from public.web_customers c where c.client_token = p_client_token limit 1;
  end if;

  -- Sem token local, usa o próprio WhatsApp como identificação do mini cadastro.
  if v_customer_id is null then
    select c.id, c.client_token into v_customer_id, v_client_token
      from public.web_customers c
      where c.whatsapp = v_phone
      order by c.created_at asc
      limit 1;
  end if;

  if v_customer_id is null then
    v_client_token := gen_random_uuid();
    insert into public.web_customers(client_token,name,whatsapp)
    values(v_client_token, trim(p_name), v_phone)
    returning id into v_customer_id;
  else
    update public.web_customers
       set name=trim(p_name), whatsapp=v_phone, updated_at=now()
     where id=v_customer_id;
  end if;

  insert into public.web_addresses(customer_id,street,number,neighborhood,complement,reference)
  values(v_customer_id,trim(p_street),trim(p_number),trim(p_neighborhood),nullif(trim(coalesce(p_complement,'')),''),nullif(trim(coalesce(p_reference,'')),''))
  returning id into v_address_id;

  with req as (
    select (j->>'product_id')::bigint product_id, sum((j->>'quantity')::integer)::integer quantity
    from jsonb_array_elements(p_items) j
    group by (j->>'product_id')::bigint
  ) select count(*) into v_requested from req;

  with req as (
    select (j->>'product_id')::bigint product_id, sum((j->>'quantity')::integer)::integer quantity
    from jsonb_array_elements(p_items) j
    group by (j->>'product_id')::bigint
  )
  select count(*), coalesce(sum(p.price * r.quantity),0)::numeric(10,2)
  into v_matched, v_total
  from req r join public.web_products p on p.id=r.product_id and p.active=true
  where r.quantity between 1 and 99;

  if v_requested <> v_matched or v_total <= 0 then raise exception 'Há produto inválido ou indisponível no carrinho'; end if;
  if p_payment_method='dinheiro' and p_change_for is not null and p_change_for < v_total then raise exception 'O valor para troco deve ser maior ou igual ao total'; end if;

  insert into public.web_orders(customer_id,address_id,payment_method,change_for,total)
  values(v_customer_id,v_address_id,p_payment_method,p_change_for,v_total)
  returning id,public_token into v_order_id,v_public_token;

  insert into public.web_order_items(order_id,product_id,product_name,unit_price,quantity,subtotal)
  select v_order_id,p.id,p.name,p.price,r.quantity,(p.price*r.quantity)::numeric(10,2)
  from (
    select (j->>'product_id')::bigint product_id, sum((j->>'quantity')::integer)::integer quantity
    from jsonb_array_elements(p_items) j
    group by (j->>'product_id')::bigint
  ) r join public.web_products p on p.id=r.product_id and p.active=true;

  return jsonb_build_object(
    'order_id',v_order_id,'public_token',v_public_token,'client_token',v_client_token,
    'total',v_total,'status','recebido','created_at',now()
  );
end;
$$;

-- Acompanhamento por token do pedido, usado para manter o pedido depois de atualizar a página.
create or replace function public.track_web_order(p_public_token uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare v_result jsonb;
begin
  select jsonb_build_object(
    'order_id',o.id,'status',o.status,'total',o.total,'payment_method',o.payment_method,
    'created_at',o.created_at,'updated_at',o.updated_at,'name',c.name,
    'items',coalesce((select jsonb_agg(jsonb_build_object('name',i.product_name,'quantity',i.quantity,'unit_price',i.unit_price,'subtotal',i.subtotal) order by i.id) from public.web_order_items i where i.order_id=o.id),'[]'::jsonb)
  ) into v_result
  from public.web_orders o
  join public.web_customers c on c.id=o.customer_id
  where o.public_token=p_public_token;
  return v_result;
end;
$$;

-- Busca os pedidos associados a um WhatsApp. Não retorna endereço.
create or replace function public.find_web_orders_by_whatsapp(p_whatsapp text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_phone text;
  v_result jsonb;
begin
  v_phone := regexp_replace(coalesce(p_whatsapp,''), '[^0-9]', '', 'g');
  if char_length(v_phone) < 10 or char_length(v_phone) > 13 then
    raise exception 'WhatsApp inválido';
  end if;

  select coalesce(jsonb_agg(x.payload order by x.created_at desc), '[]'::jsonb)
    into v_result
  from (
    select o.created_at,
      jsonb_build_object(
        'order_id',o.id,
        'public_token',o.public_token,
        'status',o.status,
        'total',o.total,
        'payment_method',o.payment_method,
        'created_at',o.created_at,
        'updated_at',o.updated_at,
        'items',coalesce((
          select jsonb_agg(jsonb_build_object('name',i.product_name,'quantity',i.quantity) order by i.id)
          from public.web_order_items i where i.order_id=o.id
        ),'[]'::jsonb)
      ) payload
    from public.web_orders o
    join public.web_customers c on c.id=o.customer_id
    where c.whatsapp=v_phone
    order by o.created_at desc
    limit 20
  ) x;

  return v_result;
end;
$$;

revoke execute on function public.place_web_order(uuid,text,text,text,text,text,text,text,text,numeric,jsonb) from public;
revoke execute on function public.track_web_order(uuid) from public;
revoke execute on function public.find_web_orders_by_whatsapp(text) from public;

grant execute on function public.place_web_order(uuid,text,text,text,text,text,text,text,text,numeric,jsonb) to anon, authenticated;
grant execute on function public.track_web_order(uuid) to anon, authenticated;
grant execute on function public.find_web_orders_by_whatsapp(text) to anon, authenticated;
